import "../App.css";

export const Footer = () => {
  return (
    <footer id="footer" class="footer bg-dark text-light text-center p-2 mt-5">
      copyright & copy ; all right reserved ; 27-04-2022
    </footer>
  );
};
